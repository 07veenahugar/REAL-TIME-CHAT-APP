import webbrowser
import pyautogui
import pyperclip
import time

def search_google(query):
    search_url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
    webbrowser.open_new(search_url)

    time.sleep(3)  # Wait for the browser to open

    pyperclip.copy(query)
    pyautogui.hotkey('ctrl', 'l')  # focus address bar
    pyautogui.hotkey('ctrl', 'v')  # paste the query
    pyautogui.press('enter')

def search_chatgpt(query):
    webbrowser.open_new("https://chat.openai.com/")
    time.sleep(5)  # Wait for ChatGPT to fully load

    pyperclip.copy(query)
    pyautogui.hotkey('ctrl', 'f')  # open search/find
    pyautogui.hotkey('ctrl', 'v')  # paste query (optional depending on layout)
    pyautogui.press('enter')

