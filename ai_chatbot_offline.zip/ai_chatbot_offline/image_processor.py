# image_processor.py

from PIL import Image
import pytesseract

def describe_image(image_path, lang='eng'):
    try:
        # Load image using PIL
        img = Image.open(image_path)
        # Extract text with pytesseract
        text = pytesseract.image_to_string(img, lang=lang)
        return text if text.strip() else "No text found in the image."
    except Exception as e:
        return f"Error processing image: {str(e)}"
