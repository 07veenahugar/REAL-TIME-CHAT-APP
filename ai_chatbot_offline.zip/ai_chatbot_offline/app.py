from flask import Flask, render_template, request, redirect, url_for, session, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from browser_fallback import search_google
from voice_output import speak_text, LANG_MAP
from fuzzywuzzy import fuzz
from PyPDF2 import PdfReader
from googletrans import Translator
from werkzeug.utils import secure_filename
from image_processor import describe_image
from gtts import gTTS
import fitz  # PyMuPDF
import uuid
import os
import json

app = Flask(__name__)
app.secret_key = "your_secret_key"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///login.db'
db = SQLAlchemy(app)
PDF_AUDIO_PATH = os.path.join("static", "pdf_audio.mp3")

UPLOAD_FOLDER = "static/uploads"
AUDIO_FOLDER = "static"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(AUDIO_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Database model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

translator = Translator()

# Load local knowledge files
with open("data/knowledge.json", "r", encoding="utf-8") as f:
    knowledge_base = json.load(f)

with open("data/math_rules.json", "r", encoding="utf-8") as f:
    math_base = json.load(f)

with open("data/grammar.json", "r", encoding="utf-8") as f:
    grammar_base = json.load(f)

# Local Q&A search
def search_local_answer(user_question):
    question = user_question.lower()
    all_data = {**knowledge_base, **math_base, **grammar_base}
    best_match = None
    highest_score = 0

    for q in all_data.keys():
        score = fuzz.token_set_ratio(question, q.lower())
        if score > highest_score:
            highest_score = score
            best_match = q

    if highest_score >= 70:
        return all_data[best_match]

    return None

# Translate
def translate_text(text, lang_code):
    lang = LANG_MAP.get(lang_code, "en")  # kn-IN -> kn
    if lang == "en":
        return text
    try:
        translated = translator.translate(text, dest=lang)
        return translated.text
    except Exception as e:
        print(f"❌ Translation failed: {e}")
        return text

# Routes
@app.route('/')
def home():
    if "user" in session:
        return render_template('chat.html', user=session["user"])
    return redirect(url_for('login'))

@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username == "ssit" and password == "ssit123":
            session["user"] = username
            return redirect(url_for('home'))
        else:
            return "Invalid username or password!"
    return render_template("login.html")

@app.route('/logout')
def logout():
    session.pop("user", None)
    return redirect(url_for('login'))

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.form["question"]
    lang = request.form.get("lang", "en-IN")

    local_answer = search_local_answer(user_input)

    if local_answer:
        translated = translate_text(local_answer, lang)
        speak_text(translated, lang)
        return jsonify({"answer": local_answer})
    else:
        fallback_msg = "I did not find the answer locally. Opening Google."
        translated = translate_text(fallback_msg, lang)
        speak_text(translated, lang)
        search_google(user_input)
        return jsonify({"answer": "Not found locally. Opened Google search in browser."})

@app.route("/upload_image", methods=["POST"])
def upload_image():
    if "image" not in request.files:
        return jsonify({"description": "No image uploaded."})

    file = request.files["image"]
    if file.filename == "":
        return jsonify({"description": "No image selected."})

    filename = secure_filename(str(uuid.uuid4()) + "_" + file.filename)
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(filepath)

    description = describe_image(filepath)
    speak_text(description, lang_code=request.form.get("lang", "en-IN"))

    return jsonify({"description": description})

@app.route('/upload_pdf', methods=['POST'])
def upload_pdf():
    if 'pdf' not in request.files:
        return jsonify({'error': 'No PDF file provided'}), 400

    file = request.files['pdf']
    lang = request.form.get('lang', 'en')

    if file.filename == '':
        return jsonify({'error': 'Empty filename'}), 400

    filename = secure_filename(file.filename)
    filepath = os.path.join("uploads", filename)
    file.save(filepath)

    try:
        # Extract text from PDF
        reader = PdfReader(filepath)
        extracted_text = ''
        for page in reader.pages:
            extracted_text += page.extract_text() or ''

        if not extracted_text.strip():
            extracted_text = "Sorry, no readable text found in the PDF."

        # Generate audio from extracted text
        tts = gTTS(text=extracted_text[:3000], lang=lang.split("-")[0])  # Limit to 3000 chars
        tts.save(PDF_AUDIO_PATH)

        return jsonify({
            'text': extracted_text[:1000]  # Just return first 1000 chars to frontend
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def extract_text_from_pdf(pdf_file):
    doc = fitz.open(stream=pdf_file.read(), filetype="pdf")
    all_text = ""
    for page in doc:
        all_text += page.get_text()
    return all_text.strip()

@app.route("/translate", methods=["POST"])
def translate_page():
    input_text = request.form.get("text")
    target_lang = request.form.get("language")

    if input_text and target_lang:
        try:
            translated = translator.translate(input_text, dest=target_lang).text
            tts = gTTS(translated, lang=target_lang)
            tts.save("static/translation_audio.mp3")
            return jsonify({"translation": translated})
        except Exception as e:
            return jsonify({"translation": f"❌ Translation failed: {str(e)}"})

    return jsonify({"translation": "Invalid input"})

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
