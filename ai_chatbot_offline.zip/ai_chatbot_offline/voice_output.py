from gtts import gTTS
import os
import tempfile
import playsound
import pyttsx3

# Map browser language codes to gTTS-compatible ones
LANG_MAP = {
    "en-IN": "en",
    "kn-IN": "kn",
    "hi-IN": "hi",
    "te-IN": "te"
}

def speak_text(text, lang_code="en-IN"):
    lang = LANG_MAP.get(lang_code, "en")

    # Use offline pyttsx3 for English only
    if lang == "en":
        try:
            engine = pyttsx3.init()
            engine.setProperty("rate", 150)
            engine.setProperty("volume", 1)

            # Optional: Choose voice
            voices = engine.getProperty("voices")
            engine.setProperty("voice", voices[1].id)  # Try English voice
            engine.say(text)
            engine.runAndWait()
        except Exception as e:
            print(f"🔊 pyttsx3 failed: {e}")
    
    # Use gTTS for other languages (requires internet)
    else:
        try:
            tts = gTTS(text=text, lang=lang)
            with tempfile.NamedTemporaryFile(delete=True, suffix=".mp3") as fp:
                tts.save(fp.name)
                playsound.playsound(fp.name)
        except Exception as e:
            print(f"🔊 gTTS failed: {e}")
